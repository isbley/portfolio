import numpy as np
import pandas as pd
empty = pd.DataFrame()

c_name = ['"foldSize"', '"unfoldSize"', '"weight"', '"term"', '"wellFold"', '"waterproof"', '"keyTest"']


empty['foldSize'] = np.random.choice(range(11,14), 9996, p=[0.01, 0.98, 0.01])
empty['unfoldSize'] = np.random.choice(range(15,18), 9996, p=[0.01, 0.98, 0.01])
empty['weight'] = np.random.choice(range(172,175), 9996, p=[0.01, 0.98, 0.01])
empty['term'] = np.random.choice(range(0,3), 9996, p=[0.01, 0.01, 0.98])
empty['wellFold'] = np.random.choice(range(0,2), 9996, p=[0.01, 0.99])
empty['waterproof'] = np.random.choice(range(0,2), 9996, p=[0.01, 0.99])
empty['keyTest'] = np.random.choice(range(14,16), 9996, p=[0.01, 0.99])

print(empty)

empty.to_csv('test0824_1.csv', index=False)